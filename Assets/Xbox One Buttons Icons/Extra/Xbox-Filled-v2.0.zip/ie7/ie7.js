/* To avoid CSS expressions while still supporting IE 7 and IE 6, use this script */
/* The script tag referencing this file must be placed before the ending body tag. */

/* Use conditional comments in order to target IE 7 and older:
	<!--[if lt IE 8]><!-->
	<script src="ie7/ie7.js"></script>
	<!--<![endif]-->
*/

(function() {
	function addIcon(el, entity) {
		var html = el.innerHTML;
		el.innerHTML = '<span style="font-family: \'Xbox-Filled\'">' + entity + '</span>' + html;
	}
	var icons = {
		'icon-Xbox-Button': '&#x71;',
		'icon-Controller': '&#x77;',
		'icon-Button-A-Filled': '&#x65;',
		'icon-Button-B-Filled': '&#x72;',
		'icon-Button-X-Filled': '&#x74;',
		'icon-Button-Y-Filled': '&#x79;',
		'icon-Untitled': '&#x75;',
		'icon-Button-View-Filled': '&#x69;',
		'icon-Share-Filled': '&#x6f;',
		'icon-Untitled3': '&#x70;',
		'icon-2': '&#x61;',
		'icon-Untitled2': '&#x73;',
		'icon-Untitled1': '&#x64;',
		'icon-Paddle-1-Filled': '&#x66;',
		'icon-Paddle-2-Filled': '&#x67;',
		'icon-Paddle-3-Filled': '&#x68;',
		'icon-Paddle-4-Filled': '&#x6a;',
		'icon-Dpad-Filled': '&#x6b;',
		'icon-Dpad-Up-Filled': '&#x6c;',
		'icon-Dpad-Right-Filled': '&#x7a;',
		'icon-Dpad-Down-Filled': '&#x78;',
		'icon-Dpad-Left-Filled': '&#x63;',
		'icon-Dpad-LR-Filled': '&#x76;',
		'icon-Dpad-UD-Filled': '&#x62;',
		'icon-Stick-L-Button-Filled': '&#x6e;',
		'icon-Stick-L-Filled': '&#x6d;',
		'icon-Stick-L-Up-Filled': '&#x31;',
		'icon-Stick-L-Right-Filled': '&#x32;',
		'icon-Stick-L-Down-Filled': '&#x33;',
		'icon-Stick-L-Left-Filled': '&#x34;',
		'icon-Stick-L-LR-Filled': '&#x35;',
		'icon-Stick-L-UD-Filled': '&#x36;',
		'icon-Stick-R-Button-Filled': '&#x37;',
		'icon-Stick-R-Filled': '&#x38;',
		'icon-Stick-R-Up-Filled': '&#x39;',
		'icon-Stick-R-Right-Filled': '&#x30;',
		'icon-Stick-R-Down-Filled': '&#x2b;',
		'icon-Stick-R-Left-Filled': '&#x2d;',
		'icon-Stick-R-LR-Filled': '&#x2a;',
		'icon-Stick-R-UD-Filled': '&#x2f;',
		'0': 0
		},
		els = document.getElementsByTagName('*'),
		i, c, el;
	for (i = 0; ; i += 1) {
		el = els[i];
		if(!el) {
			break;
		}
		c = el.className;
		c = c.match(/icon-[^\s'"]+/);
		if (c && icons[c[0]]) {
			addIcon(el, icons[c[0]]);
		}
	}
}());
